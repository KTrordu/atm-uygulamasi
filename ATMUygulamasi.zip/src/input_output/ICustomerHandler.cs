using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ATMUygulamasi.src.input_output
{
    public interface ICustomerHandler
    {
        public void DisplayCustomerScreen(ExitATMHandler exitATMHandler);
    }
}