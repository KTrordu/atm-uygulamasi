# ATM Uygulaması
C# ile yapılmış bir atm uygulaması simülasyonu.